package scalax.visitor

import scalax.util.Environment
import scalax.util.Visitor

trait TypeChecker[T, U <: Type] extends Visitor[T, T, Environment[U]]

trait SubstitutionVisitor[T, U] extends Visitor[T, T, (String, U)]

trait FreeNamesVisitor[T, U] extends Visitor[T, Set[U], Unit] {
  def visit(e:T, a:Unit = ()):Set[U]
}

trait BoundNamesVisitor[T, U] extends Visitor[T, Set[U], Unit] {
  def visit(e:T, a:Unit = ()):Set[U]
}

class NamesVisitor[T, U](fnv:FreeNamesVisitor[T, U], 
    bnv:BoundNamesVisitor[T, U]) extends Visitor[T, Set[U], Unit] {
  def visit(e:T, a:Unit = ()):Set[U] =
    (fnv visit(e)) ++ (bnv visit(e))
}