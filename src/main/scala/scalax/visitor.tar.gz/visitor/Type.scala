package scalax.visitor

trait Type {  
  def getType():Type
}