package scalax.visitor

import scalax.util.Environment

trait Typable[T, U <: Type] {  
  def isTyped():Boolean
  
  import scalax.util.Environment  
  
  def typeCheck(c:TypeChecker[T, U], e:Environment[U]):T
  
  def getRawType():Option[U]
}